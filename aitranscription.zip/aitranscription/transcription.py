import asyncio
import sys
import termios
import tty
import os
from voicerecognition import VoiceRecognizer
from llmprocessor import LLMProcessor
from dbhandler import DatabaseHandler

class NoteTaker:
    def __init__(self, api_key, output_file="appointment_notes.txt"):
        self.voice_recognizer = VoiceRecognizer()
        self.llm_processor = LLMProcessor(api_key)
        self.output_file = output_file

        # Clear the output file at the start of the appointment
        with open(self.output_file, 'w') as file:
            file.write("")

    async def take_notes(self, patient_id):
        """
        Continuously recognize speech and generate bullet points during the conversation.
        Write the bullet points to a text file.
        """
        loop = asyncio.get_running_loop()
        quit_event = asyncio.Event()

        listen_task = asyncio.create_task(self.listen_and_generate_bullets())
        quit_task = asyncio.create_task(self.wait_for_quit(quit_event))

        try:
            await quit_event.wait()
        except asyncio.CancelledError:
            pass

        # Cancel listening task if still running
        listen_task.cancel()
        try:
            await listen_task
        except asyncio.CancelledError:
            pass

        # End the appointment and handle function calls
        await self.end_appointment(patient_id)

    async def listen_and_generate_bullets(self):
        """
        Listen to the conversation and generate bullet points.
        """
        async for text in self.voice_recognizer.stream_recognize():
            if text:
                print(f"Recognized Text: {text}")
                bullet_points = await self.llm_processor.generate_bullet_points(text)
                with open(self.output_file, 'a') as file:
                    for bullet_point in bullet_points:
                        file.write(f"{bullet_point}\n")
                        print(f"Bullet Point: {bullet_point}")

    async def wait_for_quit(self, quit_event):
        """
        Wait for the user to press 'q' to quit.
        """
        loop = asyncio.get_running_loop()
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setcbreak(fd)
            while True:
                if await loop.run_in_executor(None, sys.stdin.read, 1) == 'q':
                    quit_event.set()
                    break
                await asyncio.sleep(0.1)
        except Exception as e:
            print(f"Exception in wait_for_quit: {e}")
        finally:
            # Restore terminal settings
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    async def end_appointment(self, patient_id):
        """
        Summarize the appointment and handle necessary function calls to update patient records,
        prescribe medication, and schedule next check-ups.
        """
        # Read all bullet points from the file
        with open(self.output_file, 'r') as file:
            bullet_points = file.readlines()

        # Summarize the entire conversation into a paragraph
        summary = await self.llm_processor.summarize_appointment(bullet_points)

        # Print the summarized appointment
        print(f"Appointment Summary: {summary}")

        # Handle function calls based on the summarized appointment
        await self.llm_processor.handle_function_calls(summary)

def display_all_patients():
    """
    Fetch and display all patient records from the database.
    """
    db_handler = DatabaseHandler()
    patients = db_handler.get_all_patients()
    for patient in patients:
        print(f"Patient ID: {patient[0]}")
        print(f"Name: {patient[1]}")
        print(f"Sex: {patient[2]}")
        print(f"Age: {patient[3]}")
        print(f"Race: {patient[4]}")
        print(f"Diagnoses: {patient[5]}")
        print(f"Conditions: {patient[6]}")
        print(f"Reason for Visit: {patient[7]}")
        print(f"Medications: {patient[8]}")
        print(f"Allergies: {patient[9]}")
        print(f"Height: {patient[10]}")
        print(f"Weight: {patient[11]}")
        print(f"Other Notes: {patient[12]}")
        print("========================================")

# Usage example
api_key = "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"
note_taker = NoteTaker(api_key)
patient_id = 1  # Example patient ID

# To start taking notes asynchronously
try:
    asyncio.run(note_taker.take_notes(patient_id))
except KeyboardInterrupt:
    # Ensure summarization happens if interrupted
    asyncio.run(note_taker.end_appointment(patient_id))
# To end the appointment and process the summary
# asyncio.run(note_taker.end_appointment(patient_id))

# Display all patient data
# display_all_patients()
