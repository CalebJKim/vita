import speech_recognition as sr

class VoiceRecognizer:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

    async def stream_recognize(self):
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source)
            print("Listening continuously...")
            while True:
                try:
                    audio = self.recognizer.listen(source, timeout=5)
                    text = self.recognizer.recognize_google(audio)
                    yield text
                except sr.UnknownValueError:
                    yield "Sorry, I could not understand the audio."
                except sr.RequestError as e:
                    yield f"Could not request results; {e}"
                except sr.WaitTimeoutError:
                    yield ""
